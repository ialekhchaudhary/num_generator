import 'dart:math';

import 'package:flutter/material.dart';
import 'package:num_generator/app/app.dart';
import 'package:num_generator/screen/gamescreen.dart';

void main() {
  runApp(MyApp());
}

